package com.midgardabc.day7.tanks.bf;

import java.awt.Color;

public class Brick extends SimpleBFObject {

	public Brick(int x, int y) {
		super(x, y);
		color = new Color(0, 0, 255);
	}
}
