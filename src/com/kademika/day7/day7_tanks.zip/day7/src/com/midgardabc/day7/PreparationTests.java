package com.midgardabc.day7;

import java.util.ArrayList;
import java.util.List;

public class PreparationTests {

	public static void main(String[] args) {
		List<Integer> data = new ArrayList<>();
		
		List<List<Integer>> d = new ArrayList<>();
	}

}
