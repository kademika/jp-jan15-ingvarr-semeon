package com.midgardabc.day7.tanks.bf;

import java.awt.Color;

public class Rock extends SimpleBFObject {
	
	public Rock(int x, int y) {
		super(x, y);
		color = new Color(0, 0, 255);
	}

}
