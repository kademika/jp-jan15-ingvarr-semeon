package com.midgardabc.day7.tanks.bf;

import java.awt.Graphics;

public interface Drawable {
	
	void draw(Graphics g);

}
