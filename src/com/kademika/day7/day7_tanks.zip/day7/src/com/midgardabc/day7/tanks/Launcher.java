package com.midgardabc.day7.tanks;

public class Launcher {

	public static void main(String[] args) throws Exception {
		ActionField af = new ActionField();
		af.runTheGame();
	}
}
