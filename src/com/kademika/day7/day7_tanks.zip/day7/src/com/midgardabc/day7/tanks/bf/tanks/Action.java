package com.midgardabc.day7.tanks.bf.tanks;

public enum Action {
	
	NONE, MOVE, FIRE;
	
//	, TURN_UP, TURN_RIGHT, TURN_LEFT, TURN_DOWN;
}
