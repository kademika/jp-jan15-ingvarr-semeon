package com.midgardabc.day7.tanks.bf;

import java.awt.Color;

public class Water extends SimpleBFObject {
	
	public Water(int x, int y) {
		super(x, y);
		color = new Color(0, 0, 255);
	}
}
