package com.midgardabc.day7.tanks;

public enum Direction {
	NONE, UP, DOWN, LEFT, RIGHT;
}
