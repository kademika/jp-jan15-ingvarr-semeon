package com.midgardabc.day7.tanks.bf;

public interface BFObject extends Drawable, Destroyable {
	
}
